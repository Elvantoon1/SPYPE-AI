document.addEventListener('DOMContentLoaded', function() {
    // العناصر الأساسية
    const chatHistory = document.getElementById('chatHistory');
    const userInput = document.getElementById('userInput');
    const sendButton = document.getElementById('sendButton');
    const voiceButton = document.getElementById('voiceButton');
    const clearButton = document.getElementById('clearButton');
    const themeButton = document.getElementById('themeButton');
    const typingIndicator = document.getElementById('typingIndicator');
    
    // استبدل هذا المفتاح بمفتاح API الخاص بك
    const API_KEY = 'AIzaSyCq4R2Q9rmGq7luCV-yEC1jZkSrDeyp55U';
    const API_URL = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${API_KEY}`;
    
    // تهيئة التعرف على الصوت إذا كان متاحًا
    let recognition;
    if ('webkitSpeechRecognition' in window) {
        recognition = new webkitSpeechRecognition();
        recognition.continuous = false;
        recognition.interimResults = false;
        recognition.lang = 'ar-SA';
        
        recognition.onresult = function(event) {
            const transcript = event.results[0][0].transcript;
            userInput.value = transcript;
            userInput.focus();
        };
        
        recognition.onerror = function(event) {
            console.error('خطأ في التعرف على الصوت:', event.error);
            addMessage('system', 'عذرًا، حدث خطأ في التعرف على الصوت. يرجى المحاولة مرة أخرى.');
        };
    } else {
        voiceButton.disabled = true;
        voiceButton.title = 'التعرف على الصوت غير مدعوم في متصفحك';
    }
    
    // إرسال الرسالة عند الضغط على زر الإرسال
    sendButton.addEventListener('click', sendMessage);
    
    // إرسال الرسالة عند الضغط على Enter
    userInput.addEventListener('keydown', function(e) {
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            sendMessage();
        }
        
        // تعديل ارتفاع textarea تلقائيًا
        this.style.height = 'auto';
        this.style.height = (this.scrollHeight) + 'px';
    });
    
    // تفعيل التعرف على الصوت
    voiceButton.addEventListener('click', function() {
        if (recognition) {
            try {
                recognition.start();
                voiceButton.innerHTML = '<i class="fas fa-microphone-slash"></i> إيقاف';
                voiceButton.style.backgroundColor = 'var(--accent-color)';
                
                recognition.onend = function() {
                    voiceButton.innerHTML = '<i class="fas fa-microphone"></i> صوت';
                    voiceButton.style.backgroundColor = '';
                };
            } catch (error) {
                console.error('Error starting speech recognition:', error);
            }
        }
    });
    
    // مسح المحادثة
    clearButton.addEventListener('click', function() {
        if (confirm('هل أنت متأكد أنك تريد مسح كل المحادثة؟')) {
            chatHistory.innerHTML = `
                <div class="welcome-message">
                    <p>مرحباً! أنا SPYPE AI، مساعدك الذكي. كيف يمكنني مساعدتك اليوم؟</p>
                </div>
            `;
        }
    });
    
    // تبديل الوضع المظلم
    themeButton.addEventListener('click', function() {
        const currentTheme = document.documentElement.getAttribute('data-theme');
        if (currentTheme === 'dark') {
            document.documentElement.removeAttribute('data-theme');
            themeButton.innerHTML = '<i class="fas fa-moon"></i> الوضع المظلم';
        } else {
            document.documentElement.setAttribute('data-theme', 'dark');
            themeButton.innerHTML = '<i class="fas fa-sun"></i> الوضع الفاتح';
        }
    });
    
    // وظيفة إرسال الرسالة
    function sendMessage() {
        const message = userInput.value.trim();
        if (message === '') return;
        
        // إضافة رسالة المستخدم إلى سجل المحادثة
        addMessage('user', message);
        userInput.value = '';
        userInput.style.height = 'auto';
        
        // عرض مؤشر الكتابة
        showTypingIndicator();
        
        // إرسال الرسالة إلى Gemini API
        fetch(API_URL, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                contents: [{
                    parts: [{
                        text: message
                    }]
                }]
            })
        })
        .then(response => response.json())
        .then(data => {
            hideTypingIndicator();
            
            // استخراج النص من الاستجابة
            let aiResponse = '';
            if (data.candidates && data.candidates[0].content.parts[0].text) {
                aiResponse = data.candidates[0].content.parts[0].text;
            } else {
                aiResponse = 'عذرًا، لم أتمكن من معالجة طلبك. يرجى المحاولة مرة أخرى.';
            }
            
            // إضافة رد الذكاء الاصطناعي إلى سجل المحادثة
            addMessage('ai', aiResponse);
            
            // التمرير إلى الأسفل
            chatHistory.scrollTop = chatHistory.scrollHeight;
        })
        .catch(error => {
            hideTypingIndicator();
            console.error('Error:', error);
            addMessage('ai', 'حدث خطأ في الاتصال بالخادم. يرجى التحقق من اتصالك بالإنترنت والمحاولة مرة أخرى.');
        });
    }
    
    // وظيفة إضافة رسالة إلى واجهة المستخدم
    function addMessage(sender, text) {
        const messageDiv = document.createElement('div');
        messageDiv.classList.add('message', `${sender}-message`);
        
        const messageText = document.createElement('p');
        messageText.textContent = text;
        
        const messageTime = document.createElement('span');
        messageTime.classList.add('message-time');
        messageTime.textContent = getCurrentTime();
        
        messageDiv.appendChild(messageText);
        messageDiv.appendChild(messageTime);
        
        chatHistory.appendChild(messageDiv);
        
        // التمرير إلى الأسفل
        chatHistory.scrollTop = chatHistory.scrollHeight;
    }
    
    // وظيفة عرض مؤشر الكتابة
    function showTypingIndicator() {
        typingIndicator.style.display = 'flex';
        chatHistory.scrollTop = chatHistory.scrollHeight;
    }
    
    // وظيفة إخفاء مؤشر الكتابة
    function hideTypingIndicator() {
        typingIndicator.style.display = 'none';
    }
    
    // وظيفة الحصول على الوقت الحالي
    function getCurrentTime() {
        const now = new Date();
        const hours = now.getHours().toString().padStart(2, '0');
        const minutes = now.getMinutes().toString().padStart(2, '0');
        return `${hours}:${minutes}`;
    }
    
    // تهيئة الوضع المظلم إذا كان مفضلاً
    if (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) {
        document.documentElement.setAttribute('data-theme', 'dark');
        themeButton.innerHTML = '<i class="fas fa-sun"></i> الوضع الفاتح';
    }
});